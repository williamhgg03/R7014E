function ON=intersection(BaseA,BaseB,TOL);
% Intersection computes the intersection of two vector spaces defined by
% their base. 
% Usage ON = INTERSECTION(BASEA,BASEB,TOL)
%
% ON is the resulting orthonormal base of the intersecting vector space
% BASEA, BASEB are the base for the vector spaces
% TOL is the tolerans for determining if the intersection has a valid base
% (default: 1e10 = infinity)
%
% W. Birk

if (isempty(BaseA) | isempty(BaseB))
    % The intersection is empty!!!
    ON=[];
    return;
end
    
if nargin<3
    TOL=1e10;
end

%Project the base vectors in BaseA on BaseB
P=BaseB*inv(BaseB'*BaseB)*BaseB';
for i=1:size(BaseA,2)
    IVec(:,i)=P*BaseA(:,i);
end

[EV,E]=eig(IVec*IVec');

thres=max(diag(E))/TOL;
ON=EV(:,find(diag(E)>thres));

%End of function
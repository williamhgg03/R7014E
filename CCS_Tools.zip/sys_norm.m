function N=sys_norm(G,kind)
% SYS_NORM calculates some multivariable system norms of an LTI object. 
%
%       N = SYS_NORM(G,kind)
%
%       N       resulting norm array
%       G       LTI object
%       kind    determines the norm to be calculated
%               1 = H2 norm
%               2 = Hankel norm
%               3 = upper bound of the H_infty norm
%
% W. Birk, LTU, 2014-05-22
%

[no,ni]=size(G);
Gss=ss(G);

N=zeros(no,ni);
for i=1:no
    for j=1:ni
        gc=gram(Gss(i,j),'c');
        go=gram(Gss(i,j),'o');
        
        if kind==1 % H2-norm
            N(i,j)=sqrt(abs(Gss.b(:,j)'*go*Gss.b(:,j)));
        elseif kind==2 %Hankel norm
            N(i,j)=sqrt(abs(max(eig(gc*go))));
        else % Upper bound for Hinf norm
            N(i,j)=2*sqrt(abs(sum(eig(gc*go))));
        end
    end
end

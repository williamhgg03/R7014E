function [gamma,omega]=condnum(G,omega)
%   [Gamma,omega]=condnum(G,omega) 
%
%   Calculate the condition number of an LTI-object G.
%
%	 W. Birk 99-11-19

if nargin~=2
	%   Only to get a well formated frequency vector
   [sv,omega]=sigma(G);
end

%   Compute the frequency response
Gfrsp=freqresp(G,omega);

%   Compute the condition number over the frequency
for i=1:length(omega)
   gamma(i)=cond(Gfrsp(:,:,i));
end



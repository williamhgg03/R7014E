function [gamma,omega]=condmin(G,omega)
%   [Gamma,omega]=condmin(G,omega) 
%
%   Calculate the minimized condition number of an LTI-object G.
%	 G has to be a 2x2 System!
%
%	 W. Birk 99-11-19

if size(G)==[2 2]
   if nargin==2
      [lambda,omega]=rga(G,omega);
   else
      [lambda,omega]=rga(G);
   end   
   %   Compute the condition number over the frequency
   for i=1:length(omega)
      norm1=max(sum(abs(lambda(:,:,i))));
   	gamma(i)=norm1+sqrt(norm1*norm1-1);
   end
else   
   gamma=0*omega;
   error('Can only compute minimized condition numbers for 2x2 systems!');
end





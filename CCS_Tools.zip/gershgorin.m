function gershgorin(G,type,diag);
% Computes the Gershgorin bands for a multivariable LTI system
% GERSHGORIN(G,dom,diag)
%
%   G       LTI Object
%   dom     row or column dominance
%           1 => row dominance (default)
%           2 => column dominance
%   diag    display only diagonal bands
%           0 => all bands displayed
%           else => only diagonal bands

if nargin<2
    type=1;
    diag=0;
elseif nargin<3
    diag=0;
    if type~=2
        type=1;
    end
elseif diag~=0
    diag=1;
end
[ny,nu]=size(G);
[re,im,o]=nyquist(G);

xmin=inf;
xmax=-inf;
ymin=inf;
ymax=-inf;

dist=zeros(size(re));
for w=1:length(o)
    for i=1:ny
        for j=1:nu
            if type==1
                for k=1:nu
                    if (k~=j) & (((diag~=0) & (i==j)) | (diag==0)) 
                        dist(i,j,w)=dist(i,j,w)+norm([re(i,k,w),im(i,k,w)]);                        
                    end
                end
            else
                for k=1:ny
                    if (k~=j) & (((diag~=0) & (i==j)) | (diag==0))
                        dist(i,j,w)=dist(i,j,w)+norm([re(k,j,w),im(k,j,w)]);
                    end
                end                        
            end
            if (re(i,j,w)+dist(i,j,w))>xmax
                xmax=(re(i,j,w)+dist(i,j,w));
            end
            if (re(i,j,w)-dist(i,j,w))<xmin
                xmin=(re(i,j,w)-dist(i,j,w));
            end
            if (im(i,j,w)+dist(i,j,w))>ymax
                ymax=(im(i,j,w)+dist(i,j,w));
            end
            if (im(i,j,w)-dist(i,j,w))<ymin
                ymin=(im(i,j,w)-dist(i,j,w));
            end
        end
    end
end

xmin=xmin-0.05*abs(xmin);
xmax=xmax+0.05*abs(xmax);
ymin=ymin-0.05*abs(ymin);
ymax=ymax+0.05*abs(ymax);

clf;
for i=1:ny
    for j=1:nu
        subplot(ny,nu,(i-1)*nu+j);
        grid on
        box on
        for w=1:length(o)
            circle(re(i,j,w),im(i,j,w),dist(i,j,w),[0,1,w/length(o)]);
        end
        line(squeeze(re(i,j,:)),squeeze(im(i,j,:)),'color',[1,0,0],'linestyle','--');
        line(re(i,j,1),im(i,j,1),'color',[0,0,1],'marker','x');
        line(re(i,j,length(o)),im(i,j,length(o)),'color',[0,0,1],'marker','o');
        xlim([xmin,xmax])
        ylim([ymin,ymax])
        str=sprintf('%d%d',i,j);
        xlabel(['Re(H_{',str,'}(j\omega))'])
        ylabel(['Im(H_{',str,'}(j\omega))'])
    end
end


function circle(x,y,radius,col);
if radius~=0
    line(x+radius*sin([0:0.1:2*pi+0.1]),y+radius*cos([0:0.1:2*pi+0.1]),'color',col);
end
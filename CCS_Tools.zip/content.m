% Structural analysis methods
%
% CONDNUM       Condition number of on LTI
% CONDMIN       Minimized condition number of an LTI
% GERSHGORIN    Gershgorin bands for an LTI object
% HIIA          Hankel Interaction Index Array
% NI            Niederlinski index
% PM            Participation matrix
% RGA           RGA
% RGAINF        RGA(RGA(...))
% RGAPLOT       Creates a plot of the RGA
% 
% Helper functions:
% GEOMET        Computes the Hankel Interaction Index Array and its
%               generalization
% INTERSECTION  Computes the intersection of vector spaces
% SYS_NORM      Computes system norms
% WGRAM         Computes weighted gramians
%
% W. Birk, 20081119

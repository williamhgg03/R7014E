% Geometrical approach to interaction
%
% Computes the Hankel Interaction Index Array and its generalization
% Furthermore derives all present subspaces in the MIMO SS system 
% and the intersection between them
%
% INPUT:  LTI system G
% OUTPUT: Xo   = structure that contains information on the observable subspaces
%         Xc   = structure that contains information on the controllable subspaces
%         Xco  = structure that contains information on the controllable & observable subspaces
%         Ico  = structure that contains information on the intersections of the Xco
%         HIIA = Hankel Interaction Index Array
%         HIIAg= Hankel Interaction Index Array (generalization)
%

% Do some checks and allow input of LTI object if not available
if (exist('G')~=1)
    G=input('Name of the LTI object in the workspace: ');
elseif (isa(G,'lti')~=1)
    G=input('The object G is not an LTI. Name of the LTI to use: ');
end

if (isproper(G)~=1)
    error('Can only process proper LTI systems.');
end

if issiso(G)
    error('Can only process MIMO LTI systems.');
end

% Set the tolerance for zero detection
TOL=1e10;

% Transform the system into state space and generate 
% a minimal realisation
Gss=ss(G);
[no,ni]=size(Gss);      %Determine the number of inputs and outputs
nx=size(Gss,'order');   %Determine the order of the model

% Derive the observability and controllability gramians and their
% eigenvector/-value decomposition for the scalar subsystems
clear Xo Xc
for i=1:no
    Xo(i).gram=gram(Gss(i,1),'o');
    [ev,e]=eig(Xo(i).gram);
    thres=max(diag(e))/TOL;
    p=find(diag(e)>thres);
    if isempty(p)==1  % All states are unobservable
        Xo(i).basis=[];
        Xo(i).eigenvalues=[];
        Xo(i).dimension=0;
    else              % Some or all states are observable
        Xo(i).basis=ev(:,p);
        dummy=diag(e);
        Xo(i).eigenvalues=dummy(p);
        Xo(i).dimension=length(p);
    end        
end
for i=1:ni
    Xc(i).gram=gram(Gss(1,i),'c');
    [ev,e]=eig(Xc(i).gram);
    thres=max(diag(e))/TOL;
    p=find(diag(e)>thres);
    if isempty(p)==1  % All states are uncontrollable
        Xc(i).basis=[];
        Xc(i).eigenvalues=[];
        Xc(i).dimension=0;
    else              % Some or all states are observable
        Xc(i).basis=ev(:,p);
        dummy=diag(e);
        Xc(i).eigenvalues=dummy(p);
        Xc(i).dimension=length(p);
    end        
end

% Compute the basis for both controllable and observable subspaces
% of the scalar subsystems
clear Xco
for i=1:no
    for j=1:ni
        Xco(i,j).obs_gram=Xo(i).gram;
        Xco(i,j).contr_gram=Xc(j).gram;
        Xco(i,j).basis=intersection(Xo(i).basis,Xc(j).basis);
        if isempty(Xco(i,j).basis)
            Xco(i,j).dimension=0;
        else
            Xco(i,j).dimension=size(Xco(i,j).basis,2);
        end
    end
end
            
% Compute the intersection of the Xcoij with the sum of the other
% scalar subspaces excluding Xcoij
clear Ico
for i=1:no
    for j=1:ni
        % Compute the sum of the other subspaces
        B=[];
        for r=1:no
            for s=1:ni
                if (r~=i) | (s~=j)
                    if isempty(B)
                        B=Xco(r,s).basis;
                    elseif Xco(r,s).dimension~=0
                        B=[B,Xco(r,s).basis];
                    end
                end
            end
        end

        % Compute an ON-basis for the intersection
        Ico(i,j).basis=intersection(B,Xco(i,j).basis);
        if isempty(Ico(i,j).basis)
            Ico(i,j).dimension=0;
        else
            Ico(i,j).dimension=size(Ico(i,j).basis,2);
        end
        % Compute a minimal realization for the intersection
        % if it has less dimension than nx and larger than 0
        % Then compute the gramians for the resulting system
        if Ico(i,j).dimension==Xco(i,j).dimension
            Ico(i,j).obs_gram=Xco(i,j).obs_gram;
            Ico(i,j).contr_gram=Xco(i,j).contr_gram;
        elseif Ico(i,j).dimension==0
            Ico(i,j).obs_gram=[];
            Ico(i,j).contr_gram=[];
        else
            [A,B,C,D]=ssdata(Gss(i,j));
            A=Ico(i,j).basis'*A*Ico(i,j).basis;
            B=Ico(i,j).basis'*B;
            C=C*Ico(i,j).basis;
            Gtemp=ss(A,B,C,D,Gss.Ts);
            Ico(i,j).obs_gram=gram(Gtemp,'o');
            Ico(i,j).contr_gram=gram(Gtemp,'c');
        end
    end
end

% Computation of the Hankel Interaction Index Array and its generalization
HIIA=zeros(no,ni);
HIIAg=zeros(no,ni);
for i=1:no
    for j=1:ni
        HIIA(i,j)=sqrt(max(eig(Xco(i,j).contr_gram*Xco(i,j).obs_gram)));
        if Ico(i,j).dimension==0
            HIIAg(i,j)=inf;
        else
            HIIAg(i,j)=HIIA(i,j)*HIIA(i,j)/sqrt(max(eig(Ico(i,j).contr_gram*Ico(i,j).obs_gram)));
        end
    end
end
norming=sum(sum(HIIA));
HIIA=HIIA/norming;
HIIAg=HIIAg/norming;

% Do some cleaning up
clear i j r s A B C D Gtemp p numpiv pivots ev e no ni nx Gss

% end of geomet script
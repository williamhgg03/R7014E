function [lambda,omega]=rgainf(G,omega)
%   [Lambda, Omega]=RGA(G,omega) 
%   Calculate the dynamic infinite relative gain array (RGA_inf) of an
%   LTI-object G.
%
%	 W. Birk 2014-05-22

if nargin~=2
	%   Only to get a well formated frequency vector
	[sv,omega]=sigma(G); %#ok<ASGLU>
end
%   Compute the frequency response
Gfrsp=freqresp(G,omega);

%   Compute the infinite RGA over the frequency
lambda=zeros(size(G,1),size(G,2),length(omega));
for j=1:8
	%   Compute the RGA over the frequency
   for i=1:length(omega)
   	lambda(:,:,i)=Gfrsp(:,:,i).*(pinv(Gfrsp(:,:,i))).';
   end
   Gfrsp=lambda;
end

if nargout==0
    % Plot the RGA
    clf;
    rgaplot(omega,lambda,1);
    clear lambda omega
end

